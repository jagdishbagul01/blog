const options = {
  // theme: 'dark',
};
export default options;
