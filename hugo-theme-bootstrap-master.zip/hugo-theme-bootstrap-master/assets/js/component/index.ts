interface Component {
  run();
}

export default Component;
