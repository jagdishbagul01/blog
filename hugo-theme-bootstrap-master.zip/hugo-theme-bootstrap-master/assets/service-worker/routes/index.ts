import fontRoute from "./font";
import imageRoute from "./image";
import pageRoute from "./page";
import scriptRoute from "./script";
import styleRoute from "./style";

export { fontRoute, imageRoute, pageRoute, scriptRoute, styleRoute };
