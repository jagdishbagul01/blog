// OVERRIDE THIS FILE BY CREATING "assets/docsearch/js/options.ts" TO YOUR PROJECT ROOT.
// IT'S USED TO DEFINE PARAMETERS THAT CANNOT BE CONFIGURED IN HUGO, SUCH AS JS FUNCTIONS.
// SEE ALSO https://docsearch.algolia.com/docs/api.
export default {};
