+++
# type = "docs"
title = "先决条件"
date = 2022-06-13T16:32:09+08:00
# description = "" # Used by description meta tag, summary will be used instead if not set or empty.
featured = false
draft = false
comment = true
toc = true
reward = true
pinned = false
carousel = false
categories = []
tags = ["先决条件"]
series = ["文档"]
images = []
navWeight = 90
authors = ["RazonYang"]
+++

在安装主题前，请确保你满足先决条件。

<!--more-->

## Configuration

HBS 要求设置以下配置。

{{< code-toggle filename="config" >}}
{{% config/build-write-stat %}}
{{</ code-toggle >}}

## 构建工具

{{% code/prerequisites-build-tools %}}

> 我们建议使用这些工具的最新版本。
