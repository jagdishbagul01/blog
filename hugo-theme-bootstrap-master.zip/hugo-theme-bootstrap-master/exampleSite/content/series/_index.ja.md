+++
title = "シリーズ"
[menu.main]
  parent = "blog"
  weight = 2
  [menu.main.params]
    icon = '<i class="fas fa-fw fa-columns text-info"></i>'
+++
