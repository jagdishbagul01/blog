+++
title = "Categories"
[menu.main]
  parent = "blog"
  weight = 3
  [menu.main.params]
    icon = '<i class="fas fa-fw fa-folder text-warning"></i>'
    description = 'List of Categories'
+++
