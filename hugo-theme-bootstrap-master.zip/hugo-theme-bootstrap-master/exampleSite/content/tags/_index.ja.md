+++
title = "タグ"
[menu.main]
  parent = "blog"
  weight = 4
  [menu.main.params]
    icon = '<i class="fas fa-fw fa-tags text-success"></i>'
    description = 'List of Tags'
+++
