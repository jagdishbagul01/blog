+++
title = "标签"
[menu.main]
  parent = "blog"
  weight = 4
  [menu.main.params]
    icon = '<i class="fas fa-fw fa-tags text-success"></i>'
    description = '标签列表'
+++
