+++
title = "アーカイブ"
[menu.main]
  parent = "blog"
  weight = 1
  [menu.main.params]
    icon = '<i class="fas fa-fw fa-archive text-primary"></i>'
+++
