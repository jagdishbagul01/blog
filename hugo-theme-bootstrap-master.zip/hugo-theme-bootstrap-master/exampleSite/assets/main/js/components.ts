import Component from "js/component";
import Echo from './echo';

const components: Component[] = [
    new Echo(),
];

export default components;
